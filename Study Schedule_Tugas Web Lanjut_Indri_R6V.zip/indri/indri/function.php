<?php
session_start();

// database conection
$conn = mysqli_connect("localhost", "root", "", "web_lanjut");

// insert stock
if (isset($_POST['insertmapel'])) {
	$nama = $_POST['n_mapel'];
	$hari = $_POST['hari'];
	$waktu = $_POST['waktu'];
	$sks = $_POST['sks'];

	$tambahmapel = mysqli_query($conn, "INSERT INTO mapel (n_mapel, hari, waktu, sks) values ('$nama', '$hari', '$waktu', '$sks')");
	if ($tambahmapel) {
		header('location:index.php');
	} else {
		echo "gagal";
		header('location:index.php');
	}
}

//update stock
if (isset($_POST['updatemapel'])) {
	$nama = $_POST['n_mapel'];
	$hari = $_POST['hari'];
	$waktu = $_POST['waktu'];
	$sks = $_POST['sks'];
	$ode = $_POST['kode'];
	// print_r($iduser);
	// exit();
	$updatemapel = mysqli_query($conn, "UPDATE mapel SET n_mapel='$nama', hari='$hari', waktu='$waktu' , sks='$sks' WHERE mapel.kode='$kode' ");
	if ($updatemapel) {
		header('location:index.php');
	} else {
		echo "gagal";
		header('location:index.php');
	}
}

//delete stock
if (isset($_POST['deletemapel'])) {
	$kode = $_POST['kode'];

	$deletemapel = mysqli_query($conn, "DELETE FROM mapel WHERE kode='$kode'");
	if ($deletemapel) {
		header('location:index.php');
	} else {
		echo "gagal";
		header('location:index.php');
	}
}

//insert guru
if (isset($_POST['saveguru'])) {
	$nama_g = $_POST['nama_g'];
	$no_hp = $_POST['no_hp'];
	$mapel = $_POST['mapel'];

	$tambahguru = mysqli_query($conn, "INSERT INTO guru (nama_g, mapel, telp) VALUES ('$nama_g', '$mapel', '$no_hp')");
	if ($tambahguru) {
		header('location:guru.php');
	} else {
		echo "gagal";
		header('location:guru.php');
	}
}

//update guru
if (isset($_POST['updateguru'])) {
	$nama_g = $_POST['nama_g'];
	$no_hp = $_POST['no_hp'];
	$mapel = $_POST['mapel'];
	$nip = $_POST['nip'];

	$updateguru = mysqli_query($conn, "UPDATE guru SET nama_g='$nama_g', mapel='$mapel', telp='$no_hp' WHERE nip='$nip'");
	if ($updateguru) {
		header('location:guru.php');
	} else {
		echo "gagal";
		header('location:guru.php');
	}
}

//delete guru
if (isset($_POST['deleteguru'])) {
	$id_pgw = $_POST['idguru'];

	$deleteguru = mysqli_query($conn, "delete from guru where nip='$nip'");
	if ($deleteguru) {
		header('location:guru.php');
	} else {
		echo "gagal";
		header('location:guru.php');
	}
}


//insert siswa
if (isset($_POST['savesiswa'])) {
	$nama = $_POST['nama_s'];
	$kls = $_POST['kls'];

	$tambahsiswa = mysqli_query($conn, "INSERT INTO siswa (nama_s, kls) VALUES ('$nama', '$kls')");
	if ($tambahsiswa) {
		header('location:siswa.php');
	} else {
		echo "gagal";
		header('location:siswa.php');
	}
}

//update siswa
if (isset($_POST['updatesiswa'])) {
	$nama = $_POST['nama_s'];
	$kls = $_POST['kls'];
	$nisn = $_POST['nisn'];

	$updatesiswa = mysqli_query($conn, "UPDATE siswa SET nama_s='$nama', kls='$kls' WHERE nisn='$idsiswa'");
	if ($updatesiswa) {
		header('location:siswa.php');
	} else {
		echo "gagal";
		header('location:siswa.php');
	}
}

//delete siswa
if (isset($_POST['deletesiswa'])) {
	$idds = $_POST['nisn'];

	$deletesiswa = mysqli_query($conn, "DELETE FROM siswa WHERE id_customer='$idsiswa'");
	if ($deleteds) {
		header('location:siswa.php');
	} else {
		echo "gagal";
		header('location:siswa.php');
	}
}

// insert jadwal
if (isset($_POST['savejadwal'])) {
	$siswa = $_POST['siswa'];
	$guru = $_POST['guru'];
	$mapel = $_POST['mapel'];
	$hari = $_POST['hari'];
	$waktu = $_POST['waktu'];


	$lihatstock = mysqli_query($conn, "SELECT * FROM mapel WHERE kode='$mapel[0]'");
	$stocknya = mysqli_fetch_array($lihatstock); //ambil datanya
	$stockskrg = $stocknya['stok'];

	if ($jumlah <= $stockskrg) {
		$stockupdate = $stockskrg - $hari;
		$updatestock = mysqli_query($conn, "UPDATE mapel SET stok='$stockupdate' WHERE kode = '$mapel[0]'");
		$tambahjadwal = mysqli_query($conn, "INSERT INTO jadwal (nisn, nip, kode, hari, waktu) VALUES ('$siswa', '$pegawai', '$mapel[0]', '$hari', '$waktu')");
		header('location:jadwal.php');
	} else {
		echo "gagal";
		header('location:jadwal.php');
	}
}


// delete transaksi
if (isset($_POST['deletejadwal'])) {
	$id = $_POST['id'];
	$kode = $_POST['kode'];
	$sks = $_POST['sks'];

	$lihatstock = mysqli_query($conn, "SELECT * FROM mapel where kode='$kode'");
	$stocknya = mysqli_fetch_array($lihatstock); //ambil datanya
	$stockskrg = $stocknya['stok'];

	$stockupdate = $stockskrg + $hari;
	$updatestock = mysqli_query($conn, "UPDATE mapel SET stok='$stockupdate' WHERE kode='$kode'");
	$tambahtransaksi = mysqli_query($conn, "DELETE FROM transaksi WHERE id='$id'");

	header('location:jadwal.php');
}
