<?php 

if(isset($_SESSION['logcek'])){

}else{
    header('location:login.php');
}
